#ifndef MEDIATOR_H
#define MEDIATOR_H

#include <string>
#include <vector>
#include <map>
#include <list>
#include <iostream>

#include "Command.h"

#pragma once

/**
 * @file
 * @brief Defines the ChatRoom and Users classes along with specific implementations.
 */

/**
 * @brief Abstract base class representing a chat room mediator.
 * 
 * The ChatRoom defines the communication interface for users to interact.
 * Derived classes must implement user registration and removal.
 */
class ChatRoom {

public:

    /**
     * @brief Registers a user into the chat room.
     * 
     * @param user The user to be registered.
     */
    virtual void registerUser(Users* user) = 0;

    /**
     * @brief Sends a message from one user to all others in the chat room.
     * 
     * @param message  The message content.
     * @param fromUser The sender of the message.
     */
    void sendMessage(std::string message, Users fromUser);

    /**
     * @brief Saves a message into the chat history.
     * 
     * @param message  The message content.
     * @param fromUser The sender of the message.
     */
    void saveMessage(std::string message, Users fromUser);

    /**
     * @brief Removes a user from the chat room.
     * 
     * @param user The user to be removed.
     */
    virtual void removeUser(Users* user) = 0;

    /**
     * @brief Retrieves the list of users in the chat room.
     * 
     * @return Pointer to a list of user pointers.
     */
    std::list<Users*>* getUsers();

    /**
     * @brief Increments the total number of users.
     * 
     * @return The new number of users after increment.
     */
    int incrementNumUsers();

    /**
     * @brief Gets the current number of users in the chat room.
     * 
     * @return The number of users.
     */
    int getNumUsers();

    std::list<std::string*>* getChatHistory();



private:

    std::list<Users*>* users;    /**< List of users in the chat room. */
    int numUsers = 0;            /**< Number of registered users. */
    std::list<std::string*>* chatHistory;    /**< Storage for chat history. */
};

/**
 * @brief Represents a user that participates in a chat room.
 * 
 * A user can send messages, receive messages, and maintain a queue of commands.
 */
class Users {

public:

    /**
     * @brief Sends a message to a chat room.
     * 
     * @param message The message content.
     * @param room    The chat room where the message will be sent.
     */
    void send(std::string message, ChatRoom* room);

    /**
     * @brief Receives a message from another user via the chat room.
     * 
     * @param message  The message content.
     * @param fromUser The user who sent the message.
     * @param room     The chat room through which the message was sent.
     */
    void receive(std::string message, Users fromUser, ChatRoom* room);

    /**
     * @brief Adds a command to the user's command queue.
     * 
     * @param command The command to be added.
     */
    void addCommand(Command* command);

    /**
     * @brief Executes all commands in the user's command queue.
     */
    void executeAll();

    Users(std::list<ChatRoom*> chatRooms, std::string name) {
        this->chatRooms = chatRooms;
        this->name = name;
    }

    std::string getName();

protected:

    std::list<ChatRoom*> chatRooms;   /**< Reference to the chat room(s) the user is part of. */
    std::string name;      /**< The user’s display name. */
    std::list<Command*> commandQueue; /**< Queue of commands for this user. */
};

/**
 * @brief A specific chat room implementation: Dogorithm.
 * 
 * Currently inherits ChatRoom without custom behavior.
 */
class Dogorithm : public ChatRoom {
     /**
     * @brief Registers a user into the Dogorithm chat room.
     * 
     * @param user The user to be registered.
     */
    public:
    void registerUser(Users* user) override;

    void removeUser(Users* user) override;

};

/**
 * @brief A specific chat room implementation: CtrlCat.
 * 
 * Provides a custom implementation of user registration.
 */
class CtrlCat : public ChatRoom {

    /**
     * @brief Registers a user into the CtrlCat chat room.
     * 
     * @param user The user to be registered.
     */
    public:
    void registerUser(Users* user) override;

    void removeUser(Users* user) override;
};

/**
 * @brief Example user subclass: Name1.
 * 
 * Demonstrates how custom user types can be defined.
 */
class Cat : public Users {
    public:
    Cat(std::list<ChatRoom*> chatRooms, std::string name) : Users(chatRooms, name) {}
};

/**
 * @brief Example user subclass: Name2.
 * 
 * Demonstrates how custom user types can be defined.
 */
class Dog : public Users {
    public:
    Dog(std::list<ChatRoom*> chatRooms, std::string name) : Users(chatRooms, name) {}
};

/**
 * @brief Example user subclass: Name3.
 * 
 * Demonstrates how custom user types can be defined.
 */
class CatnDog : public Users {
    public:
    CatnDog(std::list<ChatRoom*> chatRooms, std::string name) : Users(chatRooms, name) {}
};

#endif // MEDIATOR_H